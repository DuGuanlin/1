jar cvfe RABIT.jar mainfiles.RABIT mainfiles/RABIT*.class automata/*.class datastructure/*.class comparator/*.class algorithms/*.class
