
package mainfiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class ABTest {

    private static final float TD_START = 1.4f;
    private static final float TD_END = 2.2f;

    private static final int[] LAS = new int[] {
        1, 4, 8, 12
    };

    private static final int TEST_COUNT = 2;


    private static final String AB_FILE_DIR = "abtest";

    private static final String ABTEST_OUT = "abtest_out";


    private static final List<GenerateTV> AB_GENERATOR = new ArrayList<>();

    public static void main(String[] args) {
        String[] tvArgs = new String[]{
            "300",
            "",
            "0.5",
            "2",
            ""
        };
        float td = TD_START;
        File abtestDir = new File(AB_FILE_DIR);
        File abtestOutDir = new File(ABTEST_OUT);
        if (abtestDir.exists()) {
            for (File file : abtestDir.listFiles()) {
                file.delete();
            }
        } else {
            abtestDir.mkdir();
        }

        if (abtestOutDir.exists()) {
            for (File file : abtestOutDir.listFiles()) {
                file.delete();
            }
        } else {
            abtestOutDir.mkdir();
        }

        while (td <= TD_END) {
            String std = BigDecimal.valueOf(td).setScale(1, RoundingMode.HALF_UP).toString();
            tvArgs[1] = std;
            for (int i = 1; i <= TEST_COUNT; i++) {
                tvArgs[4] = AB_FILE_DIR + "/" + "aut_" + std + "_A_" + i;
                TV.main(tvArgs);
                AB_GENERATOR.add(new GenerateTV(tvArgs[0], tvArgs[2], tvArgs[3], tvArgs[1], tvArgs[4]));
                tvArgs[4] = AB_FILE_DIR + "/" + "aut_" + std + "_B_" + i;
                TV.main(tvArgs);
                AB_GENERATOR.add(new GenerateTV(tvArgs[0], tvArgs[2], tvArgs[3], tvArgs[1], tvArgs[4]));
            }
            td += 0.1f;
        }
        String[] rabitArgs = new String[] {
            "",
            "",
            "-finite2",
            "",
            "-jf",
            "-v",
            "-la",
            ""
        };

        File outFile = new File(ABTEST_OUT + "/out.csv");
        FileWriter fileWriter = null;
        try {
            if (!outFile.exists()) {
                outFile.createNewFile();
            }
            fileWriter = new FileWriter(outFile);
            fileWriter.write("file1,file2,parallel_time,serial_time,td,la,ad,alphabet_size \n");
            fileWriter.flush();
            for (int i = 0; i < AB_GENERATOR.size(); i += 2) {
                for (int la : LAS) {
                    GenerateTV aFile = AB_GENERATOR.get(i);
                    GenerateTV bFile = AB_GENERATOR.get(i + 1);
                    rabitArgs[0] = aFile.filename + ".ba";
                    rabitArgs[1] = bFile.filename + ".ba";
                    rabitArgs[3] = "-par";
                    rabitArgs[7] = String.valueOf(la);
                    long start = System.currentTimeMillis();
                    RABIT.main(rabitArgs);
                    long end = System.currentTimeMillis();
                    long parallelTime = end - start;
                    rabitArgs[3] = "";
                    start = System.currentTimeMillis();
                    RABIT.main(rabitArgs);
                    end = System.currentTimeMillis();
                    long serialTime = end - start;
                    fileWriter.append(aFile.filename + "," +
                            bFile.filename + "," +
                            parallelTime + "," +
                            serialTime + "," +
                            aFile.td + "," +
                            la + "," +
                            aFile.ad + "," +
                            aFile.alphabetSize + "\n");
                    fileWriter.flush();
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != fileWriter) {
                try {
                    fileWriter.flush();
                    fileWriter.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

    }


    static class GenerateTV {

        private String size;

        private String ad;

        private String alphabetSize;

        private String td;

        private String filename;

        public GenerateTV(String size, String ad, String alphabetSize, String td, String filename) {
            this.size = size;
            this.ad = ad;
            this.alphabetSize = alphabetSize;
            this.td = td;
            this.filename = filename;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }

        public String getAd() {
            return ad;
        }

        public void setAd(String ad) {
            this.ad = ad;
        }

        public String getAlphabetSize() {
            return alphabetSize;
        }

        public void setAlphabetSize(String alphabetSize) {
            this.alphabetSize = alphabetSize;
        }

        public String getTd() {
            return td;
        }

        public void setTd(String td) {
            this.td = td;
        }

        public String getFilename() {
            return filename;
        }

        public void setFilename(String filename) {
            this.filename = filename;
        }
    }
}

